
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import nodemailer from "nodemailer";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors());
app.use(express.json({ limit: "1mb" }));

const usersFile = path.join(__dirname, "users.json");
const complaintsFile = path.join(__dirname, "complaints.json");

async function ensureFile(file) {
    try {
        await fs.access(file);
    } catch {
        await fs.writeFile(file, "[]", "utf8");
    }
}

async function readData(file) {
    await ensureFile(file);
    return JSON.parse(await fs.readFile(file, "utf8"));
}

async function writeData(file, data) {
    await fs.writeFile(file, JSON.stringify(data, null, 2), "utf8");
}

function safeEqual(a, b) {
    const first = Buffer.from(String(a));
    const second = Buffer.from(String(b));
    return first.length === second.length &&
        crypto.timingSafeEqual(first, second);
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
    const hash = crypto.scryptSync(password, salt, 64).toString("hex");
    return { salt, hash };
}

function verifyPassword(password, saved) {
    const hash = crypto.scryptSync(password, saved.salt, 64).toString("hex");
    return safeEqual(hash, saved.hash);
}

function createToken(user) {
    const secret = process.env.SESSION_SECRET;
    if (!secret || secret.length < 32) {
        throw new Error("SESSION_SECRET must contain at least 32 characters.");
    }

    const payload = Buffer.from(JSON.stringify({
        id: user.id,
        role: user.role,
        exp: Date.now() + 1000 * 60 * 60 * 8
    })).toString("base64url");

    const signature = crypto
        .createHmac("sha256", secret)
        .update(payload)
        .digest("base64url");

    return `${payload}.${signature}`;
}

function authenticate(req, res, next) {
    try {
        const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
        const parts = token.split(".");
        if (parts.length !== 2) {
            return res.status(401).json({ success: false, message: "Please sign in again." });
        }

        const expected = crypto
            .createHmac("sha256", process.env.SESSION_SECRET || "")
            .update(parts[0])
            .digest("base64url");

        if (!safeEqual(parts[1], expected)) {
            return res.status(401).json({ success: false, message: "Invalid login session." });
        }

        const payload = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
        if (!payload.id || !payload.exp || payload.exp < Date.now()) {
            return res.status(401).json({ success: false, message: "Your session expired. Please sign in again." });
        }

        req.auth = payload;
        next();
    } catch {
        return res.status(401).json({ success: false, message: "Invalid login session." });
    }
}

function requireRole(role) {
    return (req, res, next) => {
        if (req.auth?.role !== role) {
            return res.status(403).json({ success: false, message: "You do not have permission to access this page." });
        }
        next();
    };
}

function publicUser(user) {
    return {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
    };
}

function analyzeComplaint(text) {
    const value = text.toLowerCase();
    let category = "Other";
    let priority = "Medium";
    let response = "Thank you for contacting our support team. We have received your complaint and will review it. We will update you as soon as possible.";

    if (/refund|payment|charged|billing|transaction|money/.test(value)) {
        category = "Payment Issue";
        response = "Thank you for reporting this payment concern. Our support team will review the transaction details and follow up with you. Please keep any transaction reference available.";
    } else if (/delivery|late|shipping|arrived|tracking|parcel/.test(value)) {
        category = "Delivery Issue";
        response = "We are sorry for the inconvenience with your delivery. Your complaint has been recorded, and the delivery status will need to be checked by our support team.";
    } else if (/broken|damaged|defect|cracked|faulty/.test(value)) {
        category = "Damaged Product";
        response = "We are sorry that your product did not arrive in the expected condition. We have recorded your complaint for review. Please keep your order details and any product photos available.";
    } else if (/error|app|website|technical|crash|login|bug/.test(value)) {
        category = "Technical Issue";
        response = "Thank you for reporting this technical issue. Our support team will review the information provided and follow up with troubleshooting guidance.";
    }

    if (/urgent|immediately|asap|fraud|scam|safety|danger|very angry/.test(value)) {
        priority = "High";
    }

    return { category, priority, response };
}

function escapeHtml(text = "") {
    return String(text).replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

async function sendComplaintEmail(complaint) {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
        throw new Error("Email credentials are not configured in server/.env.");
    }

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    await transporter.sendMail({
        from: `"ResolveAI Support" <${process.env.EMAIL_USER}>`,
        to: complaint.customerEmail,
        subject: `ResolveAI complaint received — ${complaint.id}`,
        text:
`Hello ${complaint.customerName},

We have received your complaint.

Complaint ID: ${complaint.id}
Product: ${complaint.product}
Category: ${complaint.category}
Priority: ${complaint.priority}

Our automatic initial response:
${complaint.response}

This is an automated acknowledgement. If your issue needs further investigation, our support team will review it.

ResolveAI Support`,
        html: `
            <div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#172033">
                <h2 style="color:#1769ff">ResolveAI</h2>
                <p>Hello ${escapeHtml(complaint.customerName)},</p>
                <p>We have received your complaint.</p>
                <p><b>Complaint ID:</b> ${escapeHtml(complaint.id)}<br>
                <b>Product:</b> ${escapeHtml(complaint.product)}<br>
                <b>Category:</b> ${escapeHtml(complaint.category)}<br>
                <b>Priority:</b> ${escapeHtml(complaint.priority)}</p>
                <h3>Automatic initial response</h3>
                <p>${escapeHtml(complaint.response)}</p>
                <p>This is an automated acknowledgement. If your issue needs further investigation, our support team will review it.</p>
                <p>Regards,<br><b>ResolveAI Support</b></p>
            </div>`
    });
}

app.get("/", (_req, res) => {
    res.json({ success: true, message: "ResolveAI backend is running." });
});

app.post("/api/auth/signup", async (req, res) => {
    try {
        const name = String(req.body.name || "").trim();
        const email = String(req.body.email || "").trim().toLowerCase();
        const password = String(req.body.password || "");

        if (!name || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({ success: false, message: "Enter a valid name and email address." });
        }
        if (password.length < 8 || password.length > 128) {
            return res.status(400).json({ success: false, message: "Password must contain 8–128 characters." });
        }

        const users = await readData(usersFile);
        if (users.some((user) => user.email === email)) {
            return res.status(409).json({ success: false, message: "An account with this email already exists." });
        }

        const passwordData = hashPassword(password);
        const user = {
            id: crypto.randomUUID(),
            name,
            email,
            role: "Customer",
            ...passwordData,
            createdAt: new Date().toISOString()
        };

        users.push(user);
        await writeData(usersFile, users);

        const safeUser = publicUser(user);
        return res.status(201).json({ success: true, user: safeUser, token: createToken(safeUser) });
    } catch (error) {
        console.error("Signup error:", error);
        return res.status(500).json({ success: false, message: "Could not create account. Check the server configuration." });
    }
});

app.post("/api/auth/login", async (req, res) => {
    try {
        const email = String(req.body.email || "").trim().toLowerCase();
        const password = String(req.body.password || "");
        const users = await readData(usersFile);
        const user = users.find((item) => item.email === email && item.role === "Customer");

        if (!user || !verifyPassword(password, user)) {
            return res.status(401).json({ success: false, message: "Incorrect email or password." });
        }

        const safeUser = publicUser(user);
        return res.json({ success: true, user: safeUser, token: createToken(safeUser) });
    } catch (error) {
        console.error("Customer login error:", error);
        return res.status(500).json({ success: false, message: "Could not sign in." });
    }
});

app.post("/api/auth/agent-login", (req, res) => {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const agentEmail = String(process.env.AGENT_EMAIL || "").trim().toLowerCase();
    const agentPassword = String(process.env.AGENT_PASSWORD || "");

    if (!agentEmail || !agentPassword) {
        return res.status(500).json({ success: false, message: "Configure AGENT_EMAIL and AGENT_PASSWORD in server/.env first." });
    }

    if (email !== agentEmail || !safeEqual(password, agentPassword)) {
        return res.status(401).json({ success: false, message: "Incorrect agent email or password." });
    }

    const user = {
        id: "resolveai-support-agent",
        name: "Customer Support Agent",
        email: agentEmail,
        role: "Customer Support Agent"
    };

    return res.json({ success: true, user, token: createToken(user) });
});

app.get("/api/auth/me", authenticate, async (req, res) => {
    if (req.auth.role === "Customer Support Agent") {
        return res.json({
            success: true,
            user: {
                id: req.auth.id,
                name: "Customer Support Agent",
                email: process.env.AGENT_EMAIL,
                role: "Customer Support Agent"
            }
        });
    }

    const users = await readData(usersFile);
    const user = users.find((item) => item.id === req.auth.id);
    if (!user) return res.status(401).json({ success: false, message: "Account not found." });

    return res.json({ success: true, user: publicUser(user) });
});

app.post("/api/complaints", authenticate, requireRole("Customer"), async (req, res) => {
    try {
        const users = await readData(usersFile);
        const user = users.find((item) => item.id === req.auth.id && item.role === "Customer");
        if (!user) return res.status(401).json({ success: false, message: "Customer account not found." });

        const product = String(req.body.product || "").trim();
        const complaintText = String(req.body.complaint || "").trim();

        if (!product || !complaintText) {
            return res.status(400).json({ success: false, message: "Enter the product and complaint details." });
        }
        if (product.length > 150 || complaintText.length > 5000) {
            return res.status(400).json({ success: false, message: "Product or complaint text is too long." });
        }

        const analysis = analyzeComplaint(complaintText);
        const complaints = await readData(complaintsFile);

        const complaint = {
            id: `RA-${Date.now().toString().slice(-8)}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`,
            customerId: user.id,
            customerName: user.name,
            customerEmail: user.email,
            product,
            complaint: complaintText,
            category: analysis.category,
            priority: analysis.priority,
            response: analysis.response,
            status: "Resolved",
            emailStatus: "Pending",
            createdAt: new Date().toISOString()
        };

        complaints.unshift(complaint);
        await writeData(complaintsFile, complaints);

        try {
            await sendComplaintEmail(complaint);
            complaint.emailStatus = "Sent";
        } catch (emailError) {
            console.error("Complaint email failed:", emailError.message);
            complaint.emailStatus = "Failed";
            complaint.emailError = emailError.message;
        }

        const updated = await readData(complaintsFile);
        const index = updated.findIndex((item) => item.id === complaint.id);
        updated[index] = complaint;
        await writeData(complaintsFile, updated);

        return res.status(201).json({
            success: true,
            message: complaint.emailStatus === "Sent"
                ? "Complaint analyzed and automatic response emailed."
                : "Complaint saved, but the email could not be sent. Check the server email settings.",
            complaint: {
                ...complaint,
                emailError: undefined
            }
        });
    } catch (error) {
        console.error("Complaint submission error:", error);
        return res.status(500).json({ success: false, message: "Could not submit the complaint." });
    }
});

app.get("/api/my-complaints", authenticate, requireRole("Customer"), async (req, res) => {
    const complaints = await readData(complaintsFile);
    const mine = complaints
        .filter((item) => item.customerId === req.auth.id)
        .map(({ emailError, ...item }) => item);

    res.json({ success: true, complaints: mine });
});

app.get("/api/complaints", authenticate, requireRole("Customer Support Agent"), async (_req, res) => {
    const complaints = await readData(complaintsFile);
    res.json({
        success: true,
        complaints: complaints.map(({ emailError, ...item }) => item)
    });
});

app.use((error, _req, res, _next) => {
    console.error("Unexpected server error:", error);
    res.status(500).json({ success: false, message: "Unexpected server error." });
});

app.listen(PORT, () => {
    console.log(`ResolveAI backend running at http://localhost:${PORT}`);
});
